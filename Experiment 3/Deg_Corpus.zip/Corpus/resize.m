cd('D:\R\preview_costs\Experiment 3\Corpus');

files= dir('img'); 
files(1:2)= []; %files(641)= [];
ResX= 1360;
ResY= 768;

for i =1:length(files)
  %a= I(1,1);
  [I, map] = imread([cd '\img\' files(i).name]);
  I= [I(:,1), I]; % make it start at 50-pixels
  add= repmat(I(:,1),1, ResX-length(I));
  I= [I, add];
  I1(1:364,1:ResX)= I(1,1); 
  I2(1:364,1:ResX)= I(1,1); 
  IF= [I1; I; I2];
  output= [cd '\resized\' '' files(i).name]; 
  imwrite (IF, map, output);
  i
end

%[I, map] = imread('corpus/bmp/1_MASK_20.bmp');

%I1(1:364,1:1024)= 229; 
%I2(1:364,1:1024)= 229; 
%IF= [I1; I; I2];
 
%imwrite (IF, map, 'test.bmp');