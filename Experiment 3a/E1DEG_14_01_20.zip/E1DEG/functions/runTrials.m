% Presentation of Experimental trials
% Martin Vasilev, 2017

global const Visual sent Monitor el; 

% Blackbox toolkit testing:
%s= serial('COM11');
%set(s, 'BaudRate', 115200, 'DataBits', 8, 'StopBits', 1, 'Parity', 'none')
%fopen(s);
%fprintf(s, 'RR');
%fprintf(s,'FF');

%const.ntrials=1; % TEMPORARY!!! Use only for testing

HideCursor; % hide the mouse cursor

% Calibrate the eye tracker
EyelinkDoTrackerSetup(el);

% Trial presentation loop:
for i=1:const.ntrials
    
    % BREAK
    if i== round(const.ntrials/2)
        MakeBreak(const.breakTime);
    end
    
    %calResult = Eyelink('CalResult');
    
%%  stimuli set-up:
    trialEnd= false; 
    
	item= design(i,1); % item is 1st column
    cond= design(i,2); % condition is 2nd column
    
    sentenceString= char(sent.Sentence(item));
    
    % load post-boundary image (always valid with 0% deg):
    if item> const.Maxtrials % practice
        postBndImg_filename= ['img\' num2str(item) '_pract_0.bmp'];
        postBndImg= read8bit(postBndImg_filename); % read in image 
        
    else % experimental
        postBndImg_filename= ['img\' num2str(item) '_valid_0.bmp'];
        postBndImg= read8bit(postBndImg_filename); % read in image
    end
    
    % Cond 1:    valid preview, 0% degradation
    % Cond 2:    orth preview, 0% degradation
    % Cond 3:    mask preview, 0% degradation
    % Cond 4:    valid preview, 20% degradation
    % Cond 5:    orth preview, 20% degradation
    % Cond 6:    mask preview, 20% degradation

    % load pre-boundary image:
    if cond < 4
        deg= '0';
    else
        deg= '20';
    end
    
    if cond==1 || cond==4
        prev= 'valid';
    end
    
    if cond==2 || cond==5
        prev= 'orth';
    end
    
    if cond==3 || cond==6
        prev= 'mask';
    end
    
    
    if item> const.Maxtrials % practice
        preBndImg_filename= ['img\' num2str(item) '_pract_' deg '.bmp'];
        preBndImg= read8bit(preBndImg_filename); % read in image 
    else % experimental
        preBndImg_filename= ['img\' num2str(item) '_' prev '_' deg '.bmp'];
        preBndImg= read8bit(preBndImg_filename); % read in image
    end
    
    % get Boundary location:
    Bnds= getBnds(sentenceString); % all word boundaries
    boundary= Bnds(sent.N_pos(item)); % target word boundary (after word N)
    All_boundary= [50, Bnds]; % all boundaries (+ before 1st word)
    %TWboundaryCrossed= false;
    %boundaryCrossed(1:length(All_boundary))= false;
    %curr_Bnd= 1; % first boundary to cross is always #1
    
    %% boundaries for each word:
    boundaryCrossed1= false;
    boundaryCrossed2= false;
    boundaryCrossed3= false;
    boundaryCrossed4= false;
    boundaryCrossed5= false;
    boundaryCrossed6= false;
    boundaryCrossed7= false;
    boundaryCrossed8= false;
    boundaryCrossed9= false;
    boundaryCrossed10= false;
    boundaryCrossed11= false;
    boundaryCrossed12= false;
    boundaryCrossed13= false;
    boundaryCrossed14= false;
    boundaryCrossed15= false;
    boundaryCrossed16= false;
    boundaryCrossed17= false;
    boundaryCrossed18= false;
    
    %%
    
    
    boundary1= All_boundary(1);
    boundary2= All_boundary(2);
    boundary3= All_boundary(3);
    boundary4= All_boundary(4);
    boundary5= All_boundary(5);
    boundary6= All_boundary(6);
    boundary7= All_boundary(7);
    boundary8= All_boundary(8);
    boundary9= All_boundary(9);
    
    if length(All_boundary)> 9
        boundary10= All_boundary(10);
    else
        boundary10= 0;
        boundaryCrossed10= true;
    end
    
    if length(All_boundary)> 10
        boundary11= All_boundary(11);
    else
        boundary11= 0;
        boundaryCrossed11= true;
    end
    
    if length(All_boundary)> 11
        boundary12= All_boundary(12);
    else
        boundary12= 0;
        boundaryCrossed12= true;
    end
    
    if length(All_boundary)> 12
        boundary13= All_boundary(13);
    else
        boundary13= 0;
        boundaryCrossed13= true;
    end
    
    if length(All_boundary)> 13
        boundary14= All_boundary(14);
    else
        boundary14= 0;
        boundaryCrossed14= true;
    end
    
    if length(All_boundary)> 14
        boundary15= All_boundary(15);
    else
        boundary15= 0;
        boundaryCrossed15= true;
    end
    
    if length(All_boundary)> 15
        boundary16= All_boundary(16);
    else
        boundary16= 0;
        boundaryCrossed16= true;
    end
    
    if length(All_boundary)> 16
        boundary17= All_boundary(17);
    else
        boundary17= 0;
        boundaryCrossed17= true;
    end
    
    if length(All_boundary)> 17
        boundary18= All_boundary(18);
    else
        boundary18= 0;
        boundaryCrossed18= true;
    end
    
    
    %% generate boundary preview buffers:
    % offscreen windows are already opened in ExpSetup.m
    
    new= preBndImg; % start with preview sentence for all words

    % Each buffer represents the sentence after the next boundary is
    % crossed (i.e., previews are incrementally replaced by the targets)
    for j= 1:length(All_boundary)
        if j~= length(All_boundary)
            new(1:768, All_boundary(j):All_boundary(j+1), :)= postBndImg(1:768, All_boundary(j):All_boundary(j+1), :);
        else
            new(1:768, All_boundary(j):Visual.resX, :)= postBndImg(1:768, All_boundary(j):Visual.resX, :);
        end   
     Screen('PutImage', Monitor.buffer(j), new); % put each preview image in respective buffer 
    end
    
    % drift check:
    EyelinkDoDriftCorrection(el);
    
    %% Eyelink & Screen trial set-up:
	stimuliOn= false;
    
    while ~stimuliOn
        if item> const.Maxtrials % if practice
            Eyelink('Message', ['TRIALID ' 'P' num2str(cond) 'I' num2str(item) 'D0']);
			% print trial ID on tracker screen:
            Eyelink('command', ['record_status_message ' [ num2str(round((i/const.ntrials)*100)) 'Prcnt:' 'P' num2str(cond) 'I' num2str(item) 'D0']]);
        else
			Eyelink('Message', ['TRIALID ' 'E' num2str(cond) 'I' num2str(item) 'D0']);
			% print trial ID on tracker screen:
			Eyelink('command', ['record_status_message ' [ num2str(round((i/const.ntrials)*100)) 'Prcnt:' 'E' num2str(cond) 'I' num2str(item) 'D0']]); 
        end
        
        % print target word boundary location to edf file:
        Eyelink('Message', ['TW BOUNDARY ' num2str(boundary)]);
        
        % print also every word boundary location to edf file:
        for k= 1:length(All_boundary)
            Eyelink('Message', ['BOUNDARY' num2str(k) ' ' num2str(All_boundary(k))]);
        end
        
        % Print image filenames to edf:
        Eyelink('Message', ['PRE-BOUNDARY IMG ' preBndImg_filename]);
        Eyelink('Message', ['POST-BOUNDARY IMG ' postBndImg_filename]);

        % print text stimuli to edf:
        stim2edf(sentenceString); % Single line
        %stim2edfML(sentenceString); % Multi-line
        
        % prepare Screens:
        % sentence presentation:
%         Screen('FillRect', Monitor.buffer(2), Visual.BGC);
%         Screen('FillRect', Monitor.buffer(4), Visual.BGC);
%         
%         % put pre-boundary image on the screen:
%         Screen('PutImage', Monitor.buffer(2), preBndImg);
%         
%         % put post-boundary image on the screen:
%         Screen('PutImage', Monitor.buffer(4), postBndImg);
        
        % see boundary (for testing)?
        if const.seeBoundary
            for k= 1:length(All_boundary)
               Screen('DrawLine', Monitor.window, Visual.FGC, All_boundary(k), 300, All_boundary(k), 500);
               Screen('DrawLine', Monitor.window, Visual.FGC, All_boundary(k), 300, All_boundary(k), 500);  
            end
           
        end
        
        
        % Use this for printing text as a string:
        %Screen('DrawText', Monitor.buffer(2), sentenceString, Visual.sentPos(1), Visual.sentPos(2), Visual.FGC); % sentence
        %DrawFormattedText(Monitor.buffer(2), sentenceString, Visual.sentPos(1), Visual.sentPos(2), Visual.FGC, ...
        %                  [], [], [], Visual.TextSpacing*1.95);
        
        if const.checkPPL
            MLcheck= strfind(sentenceString, '\n');
            
            if ~isempty(MLcheck)
                sentenceString= strrep(sentenceString, '\n', '@');
                sentenceString= strsplit(sentenceString, '@');
                sentenceString= char(sentenceString{1});
            end
            
			lngth= length(sentenceString)*Visual.Pix_per_Letter;
            Screen('FrameRect', Monitor.buffer(2), Visual.FGC, ...
                [Visual.offsetX Visual.offsetY- Visual.GazeBoxSize/2 ...
                Visual.offsetX+lngth Visual.offsetY+ Visual.GazeBoxSize]);
            
            Screen('FrameRect', Monitor.buffer(4), Visual.FGC, ...
                [Visual.offsetX Visual.offsetY- Visual.GazeBoxSize/2 ...
                Visual.offsetX+lngth Visual.offsetY+ Visual.GazeBoxSize]);
        end
        
        % Print stimuli to Eyelink monitor:
        % draw gaze box on tracker monitor:
       sendScreenshot(Monitor.buffer(1), 'disp.bmp');
        
        %% Present Gaze-box:
        stimuliOn= gazeBox(stimuliOn);
        
    end
    
    % put pre-boundary image on the screen:
    Screen('PutImage', Monitor.window, preBndImg); % contains all pre-boundary previews (whole sentence)
    
    %% Present text stimuli:
    Eyelink('Message', 'GAZE TARGET OFF');
%     Screen('CopyWindow', Monitor.buffer(2), Monitor.window);
    Screen('Flip', Monitor.window); % present sentence
    Eyelink('Message', 'DISPLAY ON');
    Eyelink('Message', 'SYNCTIME');

	trialStart= GetSecs;
    
    % copy post-boundary screen in preparation for first display change:
    Screen('CopyWindow', Monitor.buffer(1), Monitor.window);
    
    while ~trialEnd
        
        % use this for gaze-contingent manipulations:
        evt= Eyelink('NewestFloatSample');
        xpos = max(evt.gx);


%%  # 1
        if xpos >= boundary1 && ~ boundaryCrossed1
            Eyelink('Message', 'DISPLAY CHANGE STARTED W1');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W1');
            boundaryCrossed1= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(2), Monitor.window);
            Eyelink('Message', 'BOUNDARY 2 PREP DONE');
        end
        
        %%  # 2
        if xpos >= boundary2 && ~ boundaryCrossed2
            Eyelink('Message', 'DISPLAY CHANGE STARTED W2');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W2');
            boundaryCrossed2= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(3), Monitor.window);
            Eyelink('Message', 'BOUNDARY 3 PREP DONE');
        end
        
        %%  # 3
        if xpos >= boundary3 && ~ boundaryCrossed3
            Eyelink('Message', 'DISPLAY CHANGE STARTED W3');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W3');
            boundaryCrossed3= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(4), Monitor.window);
            Eyelink('Message', 'BOUNDARY 4 PREP DONE');
        end
        
        %%  # 4
        if xpos >= boundary4 && ~ boundaryCrossed4
            Eyelink('Message', 'DISPLAY CHANGE STARTED W4');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W4');
            boundaryCrossed4= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(5), Monitor.window);
            Eyelink('Message', 'BOUNDARY 5 PREP DONE');
        end
        
        %%  # 5
        if xpos >= boundary5 && ~ boundaryCrossed5
            Eyelink('Message', 'DISPLAY CHANGE STARTED W5');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W5');
            boundaryCrossed5= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(6), Monitor.window);
            Eyelink('Message', 'BOUNDARY 6 PREP DONE');
        end
        
        %%  # 6
        if xpos >= boundary6 && ~ boundaryCrossed6
            Eyelink('Message', 'DISPLAY CHANGE STARTED W6');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W6');
            boundaryCrossed6= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(7), Monitor.window);
            Eyelink('Message', 'BOUNDARY 7 PREP DONE');
        end
        
        %%  # 7
        if xpos >= boundary7 && ~ boundaryCrossed7
            Eyelink('Message', 'DISPLAY CHANGE STARTED W7');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W7');
            boundaryCrossed7= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(8), Monitor.window);
            Eyelink('Message', 'BOUNDARY 8 PREP DONE');
        end
        
        %%  # 8
        if xpos >= boundary8 && ~ boundaryCrossed8
            Eyelink('Message', 'DISPLAY CHANGE STARTED W8');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W8');
            boundaryCrossed8= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(9), Monitor.window);
            Eyelink('Message', 'BOUNDARY 9 PREP DONE');
        end
        
        %%  # 9
        if xpos >= boundary9 && ~ boundaryCrossed9
            Eyelink('Message', 'DISPLAY CHANGE STARTED W9');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W9');
            boundaryCrossed9= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 9
               Screen('CopyWindow', Monitor.buffer(10), Monitor.window);
               Eyelink('Message', 'BOUNDARY 10 PREP DONE');
            end
        end
        
        %%  # 10
        if xpos >= boundary10 && ~ boundaryCrossed10
            Eyelink('Message', 'DISPLAY CHANGE STARTED W10');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W10');
            boundaryCrossed10= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 10
               Screen('CopyWindow', Monitor.buffer(11), Monitor.window);
               Eyelink('Message', 'BOUNDARY 11 PREP DONE');
            end
        end
        
        %%  # 11
        if xpos >= boundary11 && ~ boundaryCrossed11
            Eyelink('Message', 'DISPLAY CHANGE STARTED W11');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W11');
            boundaryCrossed11= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 11
               Screen('CopyWindow', Monitor.buffer(12), Monitor.window);
               Eyelink('Message', 'BOUNDARY 12 PREP DONE');
            end
        end
        
        %%  # 12
        if xpos >= boundary12 && ~ boundaryCrossed12
            Eyelink('Message', 'DISPLAY CHANGE STARTED W12');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W12');
            boundaryCrossed12= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 12
               Screen('CopyWindow', Monitor.buffer(13), Monitor.window);
               Eyelink('Message', 'BOUNDARY 13 PREP DONE');
            end
        end
        
        %%  # 13
        if xpos >= boundary13 && ~ boundaryCrossed13
            Eyelink('Message', 'DISPLAY CHANGE STARTED W13');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W13');
            boundaryCrossed13= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 13
               Screen('CopyWindow', Monitor.buffer(14), Monitor.window);
               Eyelink('Message', 'BOUNDARY 14 PREP DONE');
            end
        end
        
        %%  # 14
        if xpos >= boundary14 && ~ boundaryCrossed14
            Eyelink('Message', 'DISPLAY CHANGE STARTED W14');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W14');
            boundaryCrossed14= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 14
               Screen('CopyWindow', Monitor.buffer(15), Monitor.window);
               Eyelink('Message', 'BOUNDARY 15 PREP DONE');
            end
        end
        
        %%  # 15
        if xpos >= boundary15 && ~ boundaryCrossed15
            Eyelink('Message', 'DISPLAY CHANGE STARTED W15');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W15');
            boundaryCrossed15= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 15
               Screen('CopyWindow', Monitor.buffer(16), Monitor.window);
               Eyelink('Message', 'BOUNDARY 16 PREP DONE');
            end
        end
        
        %%  # 16
        if xpos >= boundary16 && ~ boundaryCrossed16
            Eyelink('Message', 'DISPLAY CHANGE STARTED W16');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W16');
            boundaryCrossed16= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 16
               Screen('CopyWindow', Monitor.buffer(17), Monitor.window);
               Eyelink('Message', 'BOUNDARY 17 PREP DONE');
            end
        end
        
        %%  # 17
        if xpos >= boundary17 && ~ boundaryCrossed17
            Eyelink('Message', 'DISPLAY CHANGE STARTED W17');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W17');
            boundaryCrossed17= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 17
               Screen('CopyWindow', Monitor.buffer(18), Monitor.window);
               Eyelink('Message', 'BOUNDARY 18 PREP DONE');
            end
        end
        
        %%  # 18
        if xpos >= boundary18 && ~ boundaryCrossed18
            Eyelink('Message', 'DISPLAY CHANGE STARTED W18');
            Screen('Flip', Monitor.window); % refresh screen
            Eyelink('Message', 'DISPLAY CHANGE COMPLETED W18');
            boundaryCrossed18= true;
        end

%%        
%         if const.seeEye % FOR TESTING ONLY
%             %Screen('FillRect', Monitor.window, Visual.BGC);
%             %Screen('CopyWindow', Monitor.buffer(curr_Bnd), Monitor.window);
% 
%             Screen('DrawDots', Monitor.window, [xpos, Visual.resY/2], 10, Visual.FGC, [],2);
%             Screen('Flip', Monitor.window, [], 1);
%         end
        
        trialTime= GetSecs- trialStart;
        [x,y,buttons] = GetMouse(Monitor.window);
        trialEnd= buttons(1); % wait for mouse press (left button)
        
        % end trial automatically if no response by participant
        if trialTime> const.TrialTimeout 
             trialEnd= true;
 			 Screen('FillRect', Monitor.window, Visual.BGC); % clear subject screen
             Screen('Flip', Monitor.window);
        end
        
    end	
	
	% end of trial messages:
    Eyelink('Message', 'ENDBUTTON 5');
    Screen('FillRect', Monitor.window, Visual.BGC); % clear subject screen
    Screen('Flip', Monitor.window);
    Eyelink('Message', 'DISPLAY OFF');
    Eyelink('Message', 'TRIAL_RESULT 5');
    Eyelink('Message', 'TRIAL OK');
    
    Eyelink('StopRecording');
    Eyelink('command', 'clear_screen 0'); % clear tracker screen
    
   
     %% Questions:
      if sent.Has_quest(item)== 1
          
          % present question:
          answer= Question(char(sent.Question(item)), sent.Answer(item), ...
              item, cond, 'YES', 'NO', false);
      end   
    

end


% end of Experiment text:
%text= 'The experiment is finished! Thank you for participating!';
%Screen(Monitor.window, 'TextSize', Visual.InstrTextSize);
%Screen('DrawText', Monitor.window, text, Visual.resX/2- (Visual.Pix_per_Letter+3)*length(text)/2, Visual.resY/2, [139, 0, 0]);
%Screen('Flip', Monitor.window);
