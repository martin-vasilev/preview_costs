function [] = debrief(item)
% Displays Item on the screen to check formatting, etc.
%   Press a key to exit window
global Visual Monitor;

if nargin <1
    item= 1;
end

settings; % load settings
load('sent.mat'); % items

% get item from sentence frame:
%whichRow= find(sent.item== item & sent.cond== cond, 1);
%sentenceString= char(sent.stimuli(whichRow));
%sentenceString= strjoin(strsplit(sentenceString, '"'));

% open screen:
Screen('Preference', 'SkipSyncTests', 1); 
oldVisualDebugLevel = Screen('Preference', 'VisualDebugLevel', 3);
oldSupressAllWarnings = Screen('Preference', 'SuppressAllWarnings', 1);
	
% Find out how many screens and use largest screen number.
whichScreen = max(Screen('Screens'));

%% Setup window:
Monitor.window = Screen('OpenWindow', whichScreen);
Screen(Monitor.window, 'TextSize', Visual.FontSize);
Screen(Monitor.window, 'TextFont', Visual.Font);
Screen('FillRect', Monitor.window, Visual.BGC);
Screen('Flip', Monitor.window);

for i=1:18
   Monitor.buffer(i)= Screen(Monitor.window, 'OpenOffscreenWindow');
%    Screen(Monitor.buffer(i), 'TextSize', Visual.FontSize);
%    Screen(Monitor.buffer(i), 'TextFont', Visual.Font);
%    Screen(Monitor.buffer(i), 'TextStyle', 1); % normal
end

conditions= [4,2,3];

%% Get stimuli:
for i=1:length(conditions)
    HideCursor;
%     boundaryCrossed=false;
    trialEnd= false;
    cond= conditions(i);

    sentenceString= char(sent.Sentence(item));

    % load post-boundary image (always valid with 0% deg):
    if item> const.Maxtrials % practice
        postBndImg_filename= ['img\' num2str(item) '_pract_0.bmp'];
        postBndImg= read8bit(postBndImg_filename); % read in image 

    else % experimental
        postBndImg_filename= ['img\' num2str(item) '_valid_0.bmp'];
        postBndImg= read8bit(postBndImg_filename); % read in image
    end

    % Cond 1:    valid preview, 0% degradation
    % Cond 2:    orth preview, 0% degradation
    % Cond 3:    mask preview, 0% degradation
    % Cond 4:    valid preview, 20% degradation
    % Cond 5:    orth preview, 20% degradation
    % Cond 6:    mask preview, 20% degradation

    % load pre-boundary image:
    if cond < 4
        deg= '0';
    else
        deg= '20';
    end

    if cond==1 || cond==4
        prev= 'valid';
    end

    if cond==2 || cond==5
        prev= 'orth';
    end

    if cond==3 || cond==6
        prev= 'mask';
    end


    if item> const.Maxtrials % practice
        preBndImg_filename= ['img\' num2str(item) '_pract_' deg '.bmp'];
        preBndImg= read8bit(preBndImg_filename); % read in image 
    else % experimental
        preBndImg_filename= ['img\' num2str(item) '_' prev '_' deg '.bmp'];
        preBndImg= read8bit(preBndImg_filename); % read in image
    end

    % get Boundary location:
    Bnds= getBnds(sentenceString); % all word boundaries
    boundary= Bnds(sent.N_pos(item)); % target word boundary (after word N)
    All_boundary= [50, Bnds]; % all boundaries (+ before 1st word)
    TWboundaryCrossed= false;
    boundaryCrossed(1:length(All_boundary))= false;
    curr_Bnd= 1; % first boundary to cross is always #1
    
    %% boundaries for each word:
    boundaryCrossed1= false;
    boundaryCrossed2= false;
    boundaryCrossed3= false;
    boundaryCrossed4= false;
    boundaryCrossed5= false;
    boundaryCrossed6= false;
    boundaryCrossed7= false;
    boundaryCrossed8= false;
    boundaryCrossed9= false;
    boundaryCrossed10= false;
    boundaryCrossed11= false;
    boundaryCrossed12= false;
    boundaryCrossed13= false;
    boundaryCrossed14= false;
    boundaryCrossed15= false;
    boundaryCrossed16= false;
    boundaryCrossed17= false;
    boundaryCrossed18= false;
    
    %%
    
    
    boundary1= All_boundary(1);
    boundary2= All_boundary(2);
    boundary3= All_boundary(3);
    boundary4= All_boundary(4);
    boundary5= All_boundary(5);
    boundary6= All_boundary(6);
    boundary7= All_boundary(7);
    boundary8= All_boundary(8);
    boundary9= All_boundary(9);
    
    if length(All_boundary)> 9
        boundary10= All_boundary(10);
    else
        boundary10= 0;
        boundaryCrossed10= true;
    end
    
    if length(All_boundary)> 10
        boundary11= All_boundary(11);
    else
        boundary11= 0;
        boundaryCrossed11= true;
    end
    
    if length(All_boundary)> 11
        boundary12= All_boundary(12);
    else
        boundary12= 0;
        boundaryCrossed12= true;
    end
    
    if length(All_boundary)> 12
        boundary13= All_boundary(13);
    else
        boundary13= 0;
        boundaryCrossed13= true;
    end
    
    if length(All_boundary)> 13
        boundary14= All_boundary(14);
    else
        boundary14= 0;
        boundaryCrossed14= true;
    end
    
    if length(All_boundary)> 14
        boundary15= All_boundary(15);
    else
        boundary15= 0;
        boundaryCrossed15= true;
    end
    
    if length(All_boundary)> 15
        boundary16= All_boundary(16);
    else
        boundary16= 0;
        boundaryCrossed16= true;
    end
    
    if length(All_boundary)> 16
        boundary17= All_boundary(17);
    else
        boundary17= 0;
        boundaryCrossed17= true;
    end
    
    if length(All_boundary)> 17
        boundary18= All_boundary(18);
    else
        boundary18= 0;
        boundaryCrossed18= true;
    end
    
    
    %% generate boundary preview buffers:
    % offscreen windows are already opened in ExpSetup.m
    
    new= preBndImg; % start with preview sentence for all words

    % Each buffer represents the sentence after the next boundary is
    % crossed (i.e., previews are incrementally replaced by the targets)
    for j= 1:length(All_boundary)
        if j~= length(All_boundary)
            new(1:768, All_boundary(j):All_boundary(j+1), :)= postBndImg(1:768, All_boundary(j):All_boundary(j+1), :);
        else
            new(1:768, All_boundary(j):Visual.resX, :)= postBndImg(1:768, All_boundary(j):Visual.resX, :);
        end   
     Screen('PutImage', Monitor.buffer(j), new); % put each preview image in respective buffer 
    end

%     Screen('FillRect', Monitor.buffer(2), Visual.BGC);
%     Screen('FillRect', Monitor.buffer(4), Visual.BGC);

    % put pre-boundary image on the screen:
%     Screen('PutImage', Monitor.buffer(2), preBndImg);
% 
%     % put post-boundary image on the screen:
%     Screen('PutImage', Monitor.buffer(4), postBndImg);

    % put pre-boundary image on the screen:
    Screen('PutImage', Monitor.window, preBndImg); % contains all pre-boundary previews (whole sentence)
    
    % add boundary for easy noticing:
%     Screen('DrawLine', Monitor.buffer(2), [176,9,9], boundary, 300, boundary+1, 500);
%     Screen('DrawLine', Monitor.buffer(4), [176,9,9], boundary, 300, boundary+1, 500);

    %% "Gaze"-contingent part:

%     Screen('CopyWindow', Monitor.buffer(2), Monitor.window);
    Screen('Flip', Monitor.window); % present sentence
    Screen('CopyWindow', Monitor.buffer(4), Monitor.window);

    SetMouse(30, Visual.resY/2);
    ShowCursor(0);
    
    % copy post-boundary screen in preparation for first display change:
    Screen('CopyWindow', Monitor.buffer(1), Monitor.window);

    while ~trialEnd
        [xpos,y,buttons] = GetMouse(Monitor.window);
        trialEnd= buttons(1); % wait for mouse press (left button)

        % boundary manipulation:
        %% # 1
        if xpos >= boundary1 && ~ boundaryCrossed1
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W1');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W1');
            boundaryCrossed1= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(2), Monitor.window);
            %Eyelink('Message', 'BOUNDARY 2 PREP DONE');
        end
        
        %%  # 2
        if xpos >= boundary2 && ~ boundaryCrossed2
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W2');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W2');
            boundaryCrossed2= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(3), Monitor.window);
            %Eyelink('Message', 'BOUNDARY 3 PREP DONE');
        end
        
        %%  # 3
        if xpos >= boundary3 && ~ boundaryCrossed3
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W3');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W3');
            boundaryCrossed3= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(4), Monitor.window);
            %Eyelink('Message', 'BOUNDARY 4 PREP DONE');
        end
        
        %%  # 4
        if xpos >= boundary4 && ~ boundaryCrossed4
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W4');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W4');
            boundaryCrossed4= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(5), Monitor.window);
            %Eyelink('Message', 'BOUNDARY 5 PREP DONE');
        end
        
        %%  # 5
        if xpos >= boundary5 && ~ boundaryCrossed5
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W5');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W5');
            boundaryCrossed5= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(6), Monitor.window);
            %Eyelink('Message', 'BOUNDARY 6 PREP DONE');
        end
        
        %%  # 6
        if xpos >= boundary6 && ~ boundaryCrossed6
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W6');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W6');
            boundaryCrossed6= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(7), Monitor.window);
            %Eyelink('Message', 'BOUNDARY 7 PREP DONE');
        end
        
        %%  # 7
        if xpos >= boundary7 && ~ boundaryCrossed7
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W7');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W7');
            boundaryCrossed7= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(8), Monitor.window);
            %Eyelink('Message', 'BOUNDARY 8 PREP DONE');
        end
        
        %%  # 8
        if xpos >= boundary8 && ~ boundaryCrossed8
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W8');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W8');
            boundaryCrossed8= true;
            
            % copy buffer for next display change:
            Screen('CopyWindow', Monitor.buffer(9), Monitor.window);
            %Eyelink('Message', 'BOUNDARY 9 PREP DONE');
        end
        
        %%  # 9
        if xpos >= boundary9 && ~ boundaryCrossed9
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W9');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W9');
            boundaryCrossed9= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 9
               Screen('CopyWindow', Monitor.buffer(10), Monitor.window);
               %Eyelink('Message', 'BOUNDARY 10 PREP DONE');
            end
        end
        
        %%  # 10
        if xpos >= boundary10 && ~ boundaryCrossed10
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W10');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W10');
            boundaryCrossed10= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 10
               Screen('CopyWindow', Monitor.buffer(11), Monitor.window);
               %Eyelink('Message', 'BOUNDARY 11 PREP DONE');
            end
        end
        
        %%  # 11
        if xpos >= boundary11 && ~ boundaryCrossed11
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W11');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W11');
            boundaryCrossed11= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 11
               Screen('CopyWindow', Monitor.buffer(12), Monitor.window);
               %Eyelink('Message', 'BOUNDARY 12 PREP DONE');
            end
        end
        
        %%  # 12
        if xpos >= boundary12 && ~ boundaryCrossed12
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W12');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W12');
            boundaryCrossed12= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 12
               Screen('CopyWindow', Monitor.buffer(13), Monitor.window);
               %Eyelink('Message', 'BOUNDARY 13 PREP DONE');
            end
        end
        
        %%  # 13
        if xpos >= boundary13 && ~ boundaryCrossed13
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W13');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W13');
            boundaryCrossed13= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 13
               Screen('CopyWindow', Monitor.buffer(14), Monitor.window);
               %Eyelink('Message', 'BOUNDARY 14 PREP DONE');
            end
        end
        
        %%  # 14
        if xpos >= boundary14 && ~ boundaryCrossed14
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W14');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W14');
            boundaryCrossed14= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 14
               Screen('CopyWindow', Monitor.buffer(15), Monitor.window);
              % Eyelink('Message', 'BOUNDARY 15 PREP DONE');
            end
        end
        
        %%  # 15
        if xpos >= boundary15 && ~ boundaryCrossed15
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W15');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W15');
            boundaryCrossed15= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 15
               Screen('CopyWindow', Monitor.buffer(16), Monitor.window);
              % Eyelink('Message', 'BOUNDARY 16 PREP DONE');
            end
        end
        
        %%  # 16
        if xpos >= boundary16 && ~ boundaryCrossed16
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W16');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W16');
            boundaryCrossed16= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 16
               Screen('CopyWindow', Monitor.buffer(17), Monitor.window);
               %Eyelink('Message', 'BOUNDARY 17 PREP DONE');
            end
        end
        
        %%  # 17
        if xpos >= boundary17 && ~ boundaryCrossed17
            %Eyelink('Message', 'DISPLAY CHANGE STARTED W17');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W17');
            boundaryCrossed17= true;
            
            % copy buffer for next display change:
            if length(All_boundary)> 17
               Screen('CopyWindow', Monitor.buffer(18), Monitor.window);
              %Eyelink('Message', 'BOUNDARY 18 PREP DONE');
            end
        end
        
        %%  # 18
        if xpos >= boundary18 && ~ boundaryCrossed18
            Eyelink('Message', 'DISPLAY CHANGE STARTED W18');
            Screen('Flip', Monitor.window); % refresh screen
            %Eyelink('Message', 'DISPLAY CHANGE COMPLETED W18');
            boundaryCrossed18= true;
        end

    end

    
end



% print sentence on screen:
%DrawFormattedText(Monitor.window, sentenceString, Visual.sentPos(1), Visual.sentPos(2), Visual.FGC, ...
%                          [], [], [], Visual.TextSpacing*1.95);
% Screen('Flip', Monitor.window); % present sentence

% wait for keypress to terminate:

KbWait();
Screen('CloseAll');


end

